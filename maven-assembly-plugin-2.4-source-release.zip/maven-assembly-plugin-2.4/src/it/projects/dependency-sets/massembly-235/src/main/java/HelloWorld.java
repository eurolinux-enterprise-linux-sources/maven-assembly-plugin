public class HelloWorld
{
    public static String sayHello(String name)
    {
        return "Hello " + name + "!";
    }
}