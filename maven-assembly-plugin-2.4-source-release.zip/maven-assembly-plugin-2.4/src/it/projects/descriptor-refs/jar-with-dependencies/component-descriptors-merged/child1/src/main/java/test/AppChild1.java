package test;

/**
 * Hello world!
 *
 */
public class AppChild1 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
    }
}
